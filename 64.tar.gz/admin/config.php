<?php
declare(strict_types=1);
define('ADMIN_PASSWORD', 'admin123'); // Поменяйте пароль здесь
