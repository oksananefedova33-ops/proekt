<?php
declare(strict_types=1);
ini_set('display_errors','1'); 
error_reporting(E_ALL);

$db = __DIR__.'/data/zerro_blog.db';
@mkdir(dirname($db), 0775, true);

try {
  $pdo = new PDO('sqlite:'.$db, null, null, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch(Throwable $e) {
  http_response_code(500);
  echo "<pre>DB error: ".htmlspecialchars($e->getMessage())."</pre>";
  exit;
}

/* Базовая схема с адаптивными колонками */
$pdo->exec("CREATE TABLE IF NOT EXISTS pages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL DEFAULT 'Страница',
  data_json TEXT NOT NULL DEFAULT '{}',
  data_tablet TEXT DEFAULT '{}',
  data_mobile TEXT DEFAULT '{}',
  meta_title TEXT NOT NULL DEFAULT '',
  meta_description TEXT NOT NULL DEFAULT ''
)");

$pdo->exec("CREATE TABLE IF NOT EXISTS urls(
  page_id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL DEFAULT '',
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
)");

$pdo->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_urls_slug ON urls(slug) WHERE slug<>''");

/* Проверяем и добавляем адаптивные колонки если их нет */
function hasColumn($pdo, $table, $column) {
  $result = $pdo->query("PRAGMA table_info($table)");
  foreach($result as $row) {
    if($row['name'] === $column) return true;
  }
  return false;
}

if(!hasColumn($pdo, 'pages', 'data_tablet')) {
  $pdo->exec("ALTER TABLE pages ADD COLUMN data_tablet TEXT DEFAULT '{}'");
}
if(!hasColumn($pdo, 'pages', 'data_mobile')) {
  $pdo->exec("ALTER TABLE pages ADD COLUMN data_mobile TEXT DEFAULT '{}'");
}

/* Определяем, какую страницу показать */
$pageId = (int)($_GET['id'] ?? 0);
$slug = (string)($_GET['slug'] ?? '');

if(!$pageId) {
  if($slug !== '') {
    $st = $pdo->prepare("SELECT page_id FROM urls WHERE slug=:s");
    $st->execute(['s' => strtolower($slug)]);
    $pageId = (int)($st->fetchColumn() ?: 0);
  } else {
    $pageId = (int)$pdo->query("SELECT MIN(id) FROM pages")->fetchColumn();
  }
}

if(!$pageId) {
  $pageId = (int)$pdo->query("SELECT id FROM pages ORDER BY id DESC LIMIT 1")->fetchColumn();
}

if(!$pageId) {
  echo "<pre>Нет страниц</pre>";
  exit;
}

/* Данные страницы с адаптивными версиями */
$st = $pdo->prepare("SELECT * FROM pages WHERE id=:id");
$st->execute(['id' => $pageId]);
$row = $st->fetch();

if(!$row) {
  echo "<pre>Страница не найдена</pre>";
  exit;
}

// Декодируем данные для всех устройств
$desktop = json_decode($row['data_json'] ?? '{}', true) ?: ['elements' => []];
$tablet = json_decode($row['data_tablet'] ?? '{}', true) ?: ['elements' => []];
$mobile = json_decode($row['data_mobile'] ?? '{}', true) ?: ['elements' => []];

// Получаем язык из параметров или куки
$currentLang = $_GET['lang'] ?? $_COOKIE['site_lang'] ?? 'ru';

// Базовые значения
$title = htmlspecialchars(($row['meta_title'] ?: $row['name']), ENT_QUOTES, 'UTF-8');
$desc = htmlspecialchars($row['meta_description'] ?? '', ENT_QUOTES, 'UTF-8');

// Загружаем все переводы для текущей страницы
$translations = [];
if ($currentLang !== 'ru') {
    try {
        $transPdo = new PDO('sqlite:' . $db);
        $stmt = $transPdo->prepare("SELECT * FROM translations WHERE page_id = ? AND lang = ?");
        $stmt->execute([$pageId, $currentLang]);
        
        while ($trans = $stmt->fetch(PDO::FETCH_ASSOC)) {
            if ($trans['element_id'] === 'meta') {
                if ($trans['field'] === 'title' && !empty($trans['content'])) {
                    $title = htmlspecialchars($trans['content'], ENT_QUOTES, 'UTF-8');
                } elseif ($trans['field'] === 'description' && !empty($trans['content'])) {
                    $desc = htmlspecialchars($trans['content'], ENT_QUOTES, 'UTF-8');
                }
            } else {
                $key = $trans['element_id'] . '_' . $trans['field'];
                $translations[$key] = $trans['content'];
            }
        }
    } catch(Exception $e) {
        // Используем оригинальные значения при ошибке
    }
}

// Создаем карту элементов для быстрого поиска
$tabletMap = [];
$mobileMap = [];

foreach($tablet['elements'] as $e) {
  if(isset($e['id'])) {
    $tabletMap[$e['id']] = $e;
  }
}

foreach($mobile['elements'] as $e) {
  if(isset($e['id'])) {
    $mobileMap[$e['id']] = $e;
  }
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $title ?></title>
<meta name="description" content="<?= $desc ?>">
<style>
/* Основные стили */
body {
  margin: 0;
  background: #0e141b;
  color: #e6f0fa;
  font: 16px/1.4 system-ui, Segoe UI, Roboto;
}

.wrap {
  position: relative;
  min-height: 100vh;
  overflow-x: hidden;
}

.el {
  position: absolute;
  box-sizing: border-box;
}

/* Общие правила */
.el img, .el video {
  width: 100%;
  height: 100%;
  border-radius: inherit;
  display: block;
}

/* Для изображений */
.el[data-type="image"] img {
  object-fit: contain;
  object-position: center;
}

/* Для видео */
.el[data-type="video"] video {
  object-fit: cover;
}
/* Текстовые блоки — авто-высота и переносы длинных слов */
.el[data-type="text"] {
  height: auto;
  min-height: 30px;
  padding: 8px;
  line-height: 1.3;
  white-space: normal;
  word-wrap: break-word;
  overflow-wrap: anywhere;
  box-sizing: border-box;
}


/* Стили для кнопок */
.el.linkbtn a, .el.filebtn a {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;
}

.el.linkbtn a:hover {
  transform: scale(1.05);
  filter: brightness(1.2);
}

.el.filebtn a:hover {
  transform: scale(1.05);
  filter: brightness(1.2);
}
/* Стили для langbadge */
.el.langbadge {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding: 4px 6px;
  background: transparent;
  border: none;
}

.el.langbadge .lang-chip {
  padding: 6px 10px;
  border-radius: 10px;
  border: 1px solid #2ea8ff;
  background: #2ea8ff;
  color: #ffffff;
  font-size: 13px;
  cursor: default;
}

/* АДАПТИВНЫЕ СТИЛИ ДЛЯ DESKTOP (базовые) */
<?php foreach($desktop['elements'] as $e): 
  $id = $e['id'] ?? uniqid('el_');
  $left = (float)($e['left'] ?? 0);
  $top = (float)($e['top'] ?? 0);
  $width = (float)($e['width'] ?? 30);
  $height = (float)($e['height'] ?? 25);
  $zIndex = (int)($e['z'] ?? 1);
  $radius = (int)($e['radius'] ?? 8);
  $rotate = (float)($e['rotate'] ?? 0);
  $autoHeight = ($e['type'] === 'text');
?>
#el-<?= $id ?> {
  left: <?= $left ?>%;
  top: <?= $top ?>px;
  width: <?= $width ?>%;
  <?php if(!$autoHeight): ?>height: <?= $height ?>%;<?php endif; ?>
  z-index: <?= $zIndex ?>;
  border-radius: <?= $radius ?>px;
  transform: rotate(<?= $rotate ?>deg);
}
<?php endforeach; ?>

/* АДАПТИВНЫЕ СТИЛИ ДЛЯ TABLET */
@media (max-width: 768px) and (min-width: 481px) {
  <?php foreach($desktop['elements'] as $e): 
    $id = $e['id'] ?? '';
    if(!$id) continue;
    
    // Проверяем, есть ли данные для планшета
    if(isset($tabletMap[$id])) {
      $te = $tabletMap[$id];
      $left = (float)($te['left'] ?? 0);
      $top = (float)($te['top'] ?? 0);
      $width = (float)($te['width'] ?? 45);
      $height = (float)($te['height'] ?? 25);
      $autoHeight = ($te['type'] === 'text');
    ?>
    #el-<?= $id ?> {
      left: <?= $left ?>% !important;
      top: <?= $top ?>px !important;
      width: <?= $width ?>% !important;
      <?php if(!$autoHeight): ?>height: <?= $height ?>% !important;<?php endif; ?>
    }
    <?php
    }
  endforeach; ?>
}

/* АДАПТИВНЫЕ СТИЛИ ДЛЯ MOBILE */
@media (max-width: 480px) {
  <?php foreach($desktop['elements'] as $e): 
    $id = $e['id'] ?? '';
    if(!$id) continue;
    
    // Проверяем, есть ли данные для мобильного
    if(isset($mobileMap[$id])) {
      $me = $mobileMap[$id];
      $left = (float)($me['left'] ?? 0);
      $top = (float)($me['top'] ?? 0);
      $width = (float)($me['width'] ?? 90);
      $height = (float)($me['height'] ?? 25);
      $autoHeight = ($me['type'] === 'text');
    ?>
    #el-<?= $id ?> {
      left: <?= $left ?>% !important;
      top: <?= $top ?>px !important;
      width: <?= $width ?>% !important;
      <?php if(!$autoHeight): ?>height: <?= $height ?>% !important;<?php endif; ?>
    }
    <?php
    }
  endforeach; ?>
  
  /* Дополнительные адаптивные правила для мобильных */
  .el[data-type="text"] {
    font-size: 16px !important;
  }
  
  .el.linkbtn, .el.filebtn {
    min-height: 50px !important;
  }
}
</style>
</style>
<script>
// Глобальные переводы для всех элементов
window.siteTranslations = <?= json_encode($translations) ?>;
window.currentLang = '<?= $currentLang ?>';

document.addEventListener('DOMContentLoaded', function() {
    if (window.currentLang !== 'ru' && window.siteTranslations) {
        // Переводим текстовые элементы
        document.querySelectorAll('.el[data-type="text"]').forEach(function(el) {
            var id = el.id.replace('el-', '');
            var key = id + '_html';
            if (window.siteTranslations[key]) {
                el.innerHTML = window.siteTranslations[key];
            }
        });
        
        // Переводим кнопки
        document.querySelectorAll('.el.linkbtn a, .el.filebtn a').forEach(function(a) {
            var el = a.closest('.el');
            var id = el.id.replace('el-', '');
            var key = id + '_text';
            if (window.siteTranslations[key]) {
                // Для filebtn сохраняем иконку
                if (el.classList.contains('filebtn')) {
                    var icon = a.querySelector('span');
                    if (icon) {
                        a.innerHTML = icon.outerHTML + window.siteTranslations[key];
                    } else {
                        a.textContent = window.siteTranslations[key];
                    }
                } else {
                    a.textContent = window.siteTranslations[key];
                }
            }
        });
    }
});
</script>

</head>
<body>
<div class="wrap">
<?php 
// Выводим элементы с уникальными ID
foreach($desktop['elements'] as $e):
  $type = (string)($e['type'] ?? '');
  $id = $e['id'] ?? uniqid('el_');
  
  if($type === 'text'):
    // Сначала выводим сохранённый html (с форматированием), иначе безопасный text для старых данных
    $html  = (string)($e['html'] ?? '');
    $fs    = (int)($e['fontSize'] ?? 20);
    $color = htmlspecialchars($e['color'] ?? '#e8f2ff', ENT_QUOTES, 'UTF-8');
    $bg    = trim((string)($e['bg'] ?? ''));
    $bgStyle = $bg !== '' ? "background:{$bg};" : "";
    ?>
    <div id="el-<?= $id ?>" class="el" data-type="text"
         style="<?= $bgStyle ?>color:<?= $color ?>;font-size:<?= $fs ?>px;line-height:1.3;height:auto;">
      <?= $html !== '' ? $html : nl2br(htmlspecialchars($e['text'] ?? '', ENT_QUOTES, 'UTF-8')) ?>
    </div>
    <?php
    
  elseif($type === 'box'):
    $bg = trim((string)($e['bg'] ?? ''));
    $bd = trim((string)($e['border'] ?? ''));
    $bgStyle = $bg !== '' ? "background:{$bg};" : "";
    $bdStyle = $bd !== '' ? "border:{$bd};" : "";
    ?>
    <div id="el-<?= $id ?>" class="el" data-type="box" style="<?= $bgStyle . $bdStyle ?>"></div>
    <?php
    
  elseif($type === 'image'):
    if(!empty($e['html'])):
      ?>
      <div id="el-<?= $id ?>" class="el" data-type="image">
        <div style="width:100%;height:100%"><?= $e['html'] ?></div>
      </div>
      <?php
    else:
      $src = htmlspecialchars($e['src'] ?? '', ENT_QUOTES, 'UTF-8');
      ?>
      <div id="el-<?= $id ?>" class="el" data-type="image">
        <img src="<?= $src ?>" alt="" loading="lazy">
      </div>
      <?php
    endif;
    
  elseif($type === 'video'):
    if(!empty($e['html'])):
      ?>
      <div id="el-<?= $id ?>" class="el" data-type="video">
        <div style="width:100%;height:100%"><?= $e['html'] ?></div>
      </div>
      <?php
    else:
      $src = htmlspecialchars($e['src'] ?? '', ENT_QUOTES, 'UTF-8');
      $controls = !isset($e['controls']) || $e['controls'] ? ' controls' : '';
      $autoplay = !empty($e['autoplay']) ? ' autoplay' : '';
      $loop = !empty($e['loop']) ? ' loop' : '';
      $muted = !empty($e['muted']) ? ' muted' : '';
      ?>
      <div id="el-<?= $id ?>" class="el" data-type="video">
        <video src="<?= $src ?>"<?= $controls . $autoplay . $loop . $muted ?> playsinline></video>
      </div>
      <?php
    endif;
    
  elseif(strtolower($type) === 'linkbtn'):
    $text = htmlspecialchars($e['text'] ?? 'Кнопка', ENT_QUOTES, 'UTF-8');
    $url = htmlspecialchars($e['url'] ?? '#', ENT_QUOTES, 'UTF-8');
    $bg = htmlspecialchars(trim((string)($e['bg'] ?? '#3b82f6')), ENT_QUOTES, 'UTF-8');
    $color = htmlspecialchars(trim((string)($e['color'] ?? '#ffffff')), ENT_QUOTES, 'UTF-8');
    $radius = (int)($e['radius'] ?? 8);
    ?>
    <div id="el-<?= $id ?>" class="el linkbtn" data-type="linkbtn">
      <a href="<?= $url ?>" 
         style="background:<?= $bg ?>;color:<?= $color ?>;border-radius:<?= $radius ?>px" 
         target="_blank">
        <?= $text ?>
      </a>
    </div>
    <?php
    
  elseif(strtolower($type) === 'filebtn'):
    $text = htmlspecialchars($e['text'] ?? 'Скачать файл', ENT_QUOTES, 'UTF-8');
    $fileUrl = htmlspecialchars($e['fileUrl'] ?? '#', ENT_QUOTES, 'UTF-8');
    $fileName = htmlspecialchars($e['fileName'] ?? '', ENT_QUOTES, 'UTF-8');
    $bg = htmlspecialchars(trim((string)($e['bg'] ?? '#10b981')), ENT_QUOTES, 'UTF-8');
    $color = htmlspecialchars(trim((string)($e['color'] ?? '#ffffff')), ENT_QUOTES, 'UTF-8');
    $radius = (int)($e['radius'] ?? 8);
    
    // Определяем иконку
    $icon = '📄';
    if($fileName) {
      $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
      if(in_array($ext, ['zip','rar','7z','tar','gz','bz2'])) $icon = '📦';
      elseif($ext === 'pdf') $icon = '📕';
      elseif(in_array($ext, ['doc','docx'])) $icon = '📘';
      elseif(in_array($ext, ['xls','xlsx'])) $icon = '📗';
      elseif(in_array($ext, ['ppt','pptx'])) $icon = '📙';
      elseif(in_array($ext, ['mp3','wav','ogg','aac','flac'])) $icon = '🎵';
      elseif(in_array($ext, ['mp4','avi','mkv','mov','webm'])) $icon = '🎬';
      elseif(in_array($ext, ['jpg','jpeg','png','gif','svg','webp'])) $icon = '🖼️';
      elseif(in_array($ext, ['js','json','xml','html','css','php','py'])) $icon = '💻';
      elseif(in_array($ext, ['exe','apk','dmg','deb'])) $icon = '💿';
      elseif(in_array($ext, ['txt','md','csv'])) $icon = '📝';
    }
    ?>
    <div id="el-<?= $id ?>" class="el filebtn" data-type="filebtn">
      <a href="<?= $fileUrl ?>" 
         download="<?= $fileName ?>" 
         style="background:<?= $bg ?>;color:<?= $color ?>;border-radius:<?= $radius ?>px" 
         target="_blank">
        <span style="margin-right:8px"><?= $icon ?></span><?= $text ?>
      </a>
    </div>
    <?php
  elseif ($type === 'langbadge'):
    $langs = htmlspecialchars($e['langs'] ?? 'ru,en', ENT_QUOTES, 'UTF-8');
    $label = htmlspecialchars($e['label'] ?? 'Языки', ENT_QUOTES, 'UTF-8');
    $langsArray = explode(',', $langs);
    $currentLang = $_GET['lang'] ?? $_COOKIE['site_lang'] ?? $langsArray[0];
    
    // Сохраняем выбранный язык в куку
    if (isset($_GET['lang'])) {
        setcookie('site_lang', $_GET['lang'], time() + (365 * 24 * 60 * 60), '/');
    }
    
    
    
    
    
    // Мапинг языков на флаги и названия (полный список DeepL)
    $langMap = [
        'ru' => ['flag' => '🇷🇺', 'name' => 'Русский'],
        'en' => ['flag' => '🇬🇧', 'name' => 'English'],
        'zh-Hans' => ['flag' => '🇨🇳', 'name' => '中文'],
        'es' => ['flag' => '🇪🇸', 'name' => 'Español'],
        'fr' => ['flag' => '🇫🇷', 'name' => 'Français'],
        'de' => ['flag' => '🇩🇪', 'name' => 'Deutsch'],
        'it' => ['flag' => '🇮🇹', 'name' => 'Italiano'],
        'pt' => ['flag' => '🇵🇹', 'name' => 'Português'],
        'ja' => ['flag' => '🇯🇵', 'name' => '日本語'],
        'ko' => ['flag' => '🇰🇷', 'name' => '한국어'],
        'nl' => ['flag' => '🇳🇱', 'name' => 'Nederlands'],
        'pl' => ['flag' => '🇵🇱', 'name' => 'Polski'],
        'tr' => ['flag' => '🇹🇷', 'name' => 'Türkçe'],
        'ar' => ['flag' => '🇸🇦', 'name' => 'العربية'],
        'cs' => ['flag' => '🇨🇿', 'name' => 'Čeština'],
        'da' => ['flag' => '🇩🇰', 'name' => 'Dansk'],
        'el' => ['flag' => '🇬🇷', 'name' => 'Ελληνικά'],
        'fi' => ['flag' => '🇫🇮', 'name' => 'Suomi'],
        'hu' => ['flag' => '🇭🇺', 'name' => 'Magyar'],
        'id' => ['flag' => '🇮🇩', 'name' => 'Indonesia'],
        'no' => ['flag' => '🇳🇴', 'name' => 'Norsk'],
        'ro' => ['flag' => '🇷🇴', 'name' => 'Română'],
        'sv' => ['flag' => '🇸🇪', 'name' => 'Svenska'],
        'uk' => ['flag' => '🇺🇦', 'name' => 'Українська'],
        'bg' => ['flag' => '🇧🇬', 'name' => 'Български'],
        'et' => ['flag' => '🇪🇪', 'name' => 'Eesti'],
        'lt' => ['flag' => '🇱🇹', 'name' => 'Lietuvių'],
        'lv' => ['flag' => '🇱🇻', 'name' => 'Latviešu'],
        'sk' => ['flag' => '🇸🇰', 'name' => 'Slovenčina'],
        'sl' => ['flag' => '🇸🇮', 'name' => 'Slovenščina'],
        'hi' => ['flag' => '🇮🇳', 'name' => 'हिन्दी']
    ];
    
    $currentLangData = $langMap[trim($currentLang)] ?? ['flag' => '🌐', 'name' => strtoupper(trim($currentLang))];
    ?>
    <div id="el-<?= $id ?>" class="el langbadge" data-type="langbadge" data-langs="<?= $langs ?>">
      <div class="langbadge__wrap">
        <div class="lang-selector" onclick="this.querySelector('.lang-dropdown').classList.toggle('show')">
          <div class="lang-chip">
            <span class="lang-flag"><?= $currentLangData['flag'] ?></span>
            <span class="lang-name"><?= $currentLangData['name'] ?></span>
          </div>
          <div class="lang-dropdown">
            <?php foreach($langsArray as $lang): 
                $lang = trim($lang);
                $langData = $langMap[$lang] ?? ['flag' => '🌐', 'name' => strtoupper($lang)];
            ?>
              <a href="?lang=<?= $lang ?>" class="lang-option">
                <span class="lang-flag"><?= $langData['flag'] ?></span>
                <span class="lang-name"><?= $langData['name'] ?></span>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
    <style>
    .el.langbadge { background: transparent !important; border: none !important; padding: 0 !important; }
    .lang-selector { position: relative; cursor: pointer; display: inline-block; }
    .lang-chip { padding: 8px 16px; border-radius: 12px; background: #1a2533; border: 1px solid #2ea8ff; color: #fff; display: flex; align-items: center; gap: 8px; font-size: 14px; transition: all 0.3s ease; }
    .lang-chip:hover { background: #2ea8ff; transform: scale(1.05); }
    .lang-flag { font-size: 20px; }
    .lang-dropdown { 
      position: absolute; 
      top: calc(100% + 8px); 
      left: 0; 
      background: #1a2533; 
      border: 1px solid #2ea8ff; 
      border-radius: 12px; 
      padding: 8px; 
      z-index: 10000; 
      display: none; 
      min-width: 260px; 
      max-height: 380px;
      overflow-y: auto;
      overflow-x: hidden;
      box-shadow: 0 4px 20px rgba(46, 168, 255, 0.3); 
    }
    .lang-dropdown::-webkit-scrollbar { width: 8px; }
    .lang-dropdown::-webkit-scrollbar-track { background: #0b111a; border-radius: 4px; }
    .lang-dropdown::-webkit-scrollbar-thumb { background: #2a3f5f; border-radius: 4px; }
    .lang-dropdown::-webkit-scrollbar-thumb:hover { background: #3a5070; }
    .lang-dropdown.show { display: block !important; }
    .lang-option { display: flex; align-items: center; gap: 8px; padding: 8px 12px; color: #fff; text-decoration: none; border-radius: 8px; transition: all 0.2s ease; white-space: nowrap; }
    .lang-option:hover { background: #2ea8ff; transform: translateX(4px); }
    </style>
    <?php
  endif;
endforeach; 
?>
</div>
</body>
</html>